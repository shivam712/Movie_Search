import { NgModule } from  "@angular/core";
import { BrowserModule } from  "@angular/platform-browser";
import { FormsModule } from  "@angular/forms";
import { HttpClientModule } from  "@angular/common/http";
import { DefaultImagePipe } from './default-image.pipe';
import { EllipsifyPipe } from './ellipsify.pipe';
import { SplitStringPipe } from './split-string.pipe';

@NgModule({
    imports: [ BrowserModule, FormsModule, HttpClientModule ],
    declarations: [DefaultImagePipe, EllipsifyPipe, SplitStringPipe],
    exports:  [DefaultImagePipe,  EllipsifyPipe,  SplitStringPipe],
    providers: []
})
export  class UtilsModule {}